# command64 Programmer's Reference

This document provides technical details for developing applications for the command64 operating system.

## 1. Memory Map

When Command 64 OS starts, the shell banks out the **C64 BASIC ROM** at `$A000-$BFFF` by writing to the 6510 CPU Port register at `$0001` (clearing bit 0, `LORAM`). This exposes the underlying RAM, providing a contiguous user program space from `UserProgStart` (currently `$3800`, configurable via the CMake cache variable `USER_PROG_START_HEX`) up to `$CFFF` (since `$C000-$CFFF` is reserved for the VMM Memory Control Table). The **KERNAL ROM** (`$E000-$FFFF`) and **I/O space** (`$D000-$DFFF`) remain active to support system calls, hardware devices, and REU operations.

> **Note:** `UserProgStart` has shifted upward several times as resident OS segments (`AppTable`, `ShellExt`) have grown ($2000 → $2200 → $2600 → $2C00 → $3200 → $3400 → current `$3800`). Applications should never hardcode `$3400` or any other prior value — always link/compile against the current `USER_PROG_START_HEX` CMake cache variable so binaries stay valid across OS builds. CASM's independent default emission origin remains `$3400`; its R6 output is relocated when loaded. Non-relocatable binaries compiled for a stale origin can still be loaded at an arbitrary address via the Binary Relocator (see §6.5).

### C64 RAM Banking Control ($0001 CPU Port)

* **Bit 0 (`LORAM`) = 0**: Banks out BASIC ROM, exposing RAM at `$A000-$BFFF`.
* **Bit 1 (`HIRAM`) = 1**: Keeps KERNAL ROM active at `$E000-$FFFF`.
* **Bit 2 (`CHAREN`) = 1**: Keeps I/O registers mapped at `$D000-$DFFF`.

### Base RAM Layout

```text
  Address |    Region Size / Description                          | Access / State         |
+---------+-------------------------------------------------------+------------------------+
|  $FFFF  |  Interrupt Vectors ($FFFA-$FFFF)                      |  KERNAL ROM (Active)   |
|         |  KERNAL ROM Jump Table ($FF00-$FFF9)                  |                        |
|  $E000  |  C64 KERNAL ROM Code Space                            |                        |
+---------+-------------------------------------------------------+------------------------+
|  $DFFF  |  REU Hardware Registers ($DF00-$DF0A)                 |  Hardware Registers
|  $D000  |  I/O Registers (VIC-II, SID, CIA-1, CIA-2)            |  (CHAREN = 1)
+---------+-------------------------------------------------------+------------------------+
|  $CFFF  |  VMM Memory Control Table (MCT)                       |  OS Reserved RAM
|  $C000  |  Tracks 4096 pages (4KB each) over 16MB REU space     |  (4KB Base RAM)
+---------+-------------------------------------------------------+------------------------+
|  $BFFF  |                                                       |  
|         |  User Program Space (RAM)                             |  User Application Area
|         |  (Note: BASIC ROM banked out at $A000-$BFFF to        |  (RAM replacing ROM)
|         |   provide contiguous program RAM)                     |
|UserProgStart|  (`$3800` in the default build; grows over time  |
|         |   as OS segments below it expand — see note above)    |
+---------+-------------------------------------------------------+------------------------+
|  $37FF  |  OS-Reserved Padding / Alignment Room                 |  Free RAM (size varies
|  $3539  |  (headroom for future ApiExt/ShellExt/AppTable growth)|  build to build)
+---------+-------------------------------------------------------+
|  $3538  |  ApiExt Segment                                       |  OS API Handler
|  $32C6  |  Dispatch tables plus API service handler bodies that |  Bodies (RAM)
|         |  do not fit below the ApiStub pinned at $1000 —       |
|         |  currently DOS_GET_SYSTEM_INFO / DOS_GET_APP_INFO     |
+---------+-------------------------------------------------------+
|  $32C5  |  ShellExt Segment                                     |  OS Shell Data
|  $2495  |  Version, help strings, DIR size-calc routines, and   |  (RAM)
|         |  file I/O/date-time internal state (see note below)   |
+---------+-------------------------------------------------------+
|  $2494  |  AppTable Segment                                     |  OS Resident Registry
|  $2000  |  Application Registry Management API (aptInit/Find/   |  (RAM)
|         |  Register/Remove/List/FindFreeRegion/CheckRange/etc.) |
+---------+-------------------------------------------------------+
|  $1FFF  |  VMM Data Segment                                     |  OS VMM Data
|         |  vmmInitialized ($1FA0), vmmTempByte ($1FA1)          |  (RAM)
|  $1FA0  |  fileScratch ($1FA2-$1FFB, 90 bytes),                 |
|         |  SysDateYear/Month/Day/LastHour ($1FFC-$1FFF)         |
+---------+-------------------------------------------------------+
|  $1F31  |  Command Shell                                        |  OS Shell Code
|  $10F1  |  Command parser, command tables, built-in handlers    |  (RAM)
+---------+-------------------------------------------------------+
|  $10F0  |  Command Table / System Tables                        |  OS Data
|  $1019  |  Command name listings and dispatcher mapping         |  (RAM)
+---------+-------------------------------------------------------+
|  $1018  |  PETSCII Library                                      |  OS Library
|  $1003  |  Print character / print string utilities             |  (RAM)
+---------+-------------------------------------------------------+
|  $1002  |  ApiStub (OS Stable Jump Table Entry Point)           |  OS Entry Point
|  $1000  |  Jump to apiHandler (jmp $1200+); JSR $1000 target    |  (RAM)
+---------+-------------------------------------------------------+
|  $0FFF  |  OS Core Code Space                                   |  OS Kernel Code
|         |  $0D00-$0FFF: OS Core (Loader, Path, File System)     |  (RAM)
|  $0820  |  $0820-$0CFF: OS Utils (Hex parsing, Decimal printer) |
+---------+-------------------------------------------------------+
|  $081F  |  Main BASIC SYS Launcher                              |  BASIC Stub
|  $0801  |  Contains 10 SYS 4608 / sys 4096 (Upstart launcher)   |  (RAM)
+---------+-------------------------------------------------------+
|  $0800  |  Unused / BASIC Start Marker                          |  RAM
+---------+-------------------------------------------------------+
|  $07FF  |  C64 Screen Memory                                    |  Standard Screen RAM
|  $0400  |  1000 character matrices (40x25 character display)    |  (RAM)
+---------+-------------------------------------------------------+
|  $03FF  |  C64 KERNAL & OS Workspace / Buffers                  |  System / Tape Buffer
|  $0200  |  Includes keyboard buffer and Cassette Buffer ($033C)  |  (RAM)
+---------+-------------------------------------------------------+
|  $01FF  |  C64 System Stack                                     |  Standard 6502 Stack
|  $0100  |  Used for JSR returns and PHA/PHP storage             |  (RAM)
+---------+-------------------------------------------------------+
|  $00FF  |  Zero Page RAM                                        |  Processor Workspace
|  $0000  |  OS scratch pointers, VMM registers, KERNAL system ZP |  (RAM)
+---------+-------------------------------------------------------+
```

---

## 2. Zero Page Layout ($0000 - $00FF)

Applications MUST respect the following zero page allocations to prevent corrupting operating system operations or standard KERNAL subsystems.

| Range | Constant / Label | Purpose | State Owner |
|-------|------------------|---------|-------------|
| `$00 - $01` | `D6510` / `R6510` | 6510 CPU Port Direction & Data Register | Hardware |
| `$02` | `CmpBase` | String comparison scratch workspace base offset | OS Core |
| `$03 - $60` | - | **Safe Area for User Applications** | User Apps |
| `$61 - $62` | `HandlerVecLo/Hi` | Dynamic Shell handler vector for API dispatcher | OS Shell |
| `$63` | `ParsePos` | Pointer offset inside the CommandBuffer command parser | OS Shell |
| `$64 - $65` | `TempLo/Hi` | Operating System general utility scratch bytes | OS Core |
| `$66 - $67` | `HexValLo/Hi` | Hex parsing output storage / Address pointer | OS Core |
| `$68 - $69` | `VmmSegLo/Hi` | VMM 16-bit logical Segment address parameter | OS VMM |
| `$6A - $6B` | `VmmOffLo/Hi` | VMM 16-bit logical Offset address parameter | OS VMM |
| `$6C` | `VmmBank` | VMM 1MB block index (0-15) for physical mapping | OS VMM |
| `$6D` | `FileHandle` | Current active file handle for handle-based I/O | OS File System |
| `$6E` | `SrcHandle` | Source file handle scratch for utility routines (`cmdCopy`) | OS Shell |
| `$6F` | `DstHandle` | Destination file handle scratch for utility routines (`cmdCopy`) | OS Shell |
| `$70 - $8F` | - | **Safe for User Application use** (Note: `DEBUG.PRG` uses `$70-$7F`) | User Apps |
| `$90 -`$FA` | - | Standard C64 KERNAL I/O and hardware vectors | KERNAL |
| `$FB - $FC` | `PrintPtrLo/Hi` | String print pointer workspace (`petPrintString`) | OS Core |
| `$FD - $FE` | `NamePtrLo/Hi` | File loader wrapper filename pointer | OS Core |
| `$FF` | - | KERNAL keyboard scan tracker / Stack boundary marker | KERNAL |

---

## 3. Cassette Buffer Workspace Layout ($033C - $03FF)

The 192-byte cassette buffer region (`$033C-$03FB`) is reused as the persistent workspace for OS variables, file handles, and shell configurations. Because tape storage is bypassed by Command 64 OS, this region provides a secure, non-clobbered RAM page.

```text
  Address       Byte-by-Byte Cassette Buffer Allocation Map
+---------+-------------------------------------------------------+
|  $03FF  |  Remaining C64 KERNAL Workspace / System Pointers     |
|  $03FC  |                                                       |
+---------+-------------------------------------------------------+
|  $03FB  |  Reserved / Unallocated Free Space                    |
|  $03FA  |  (2 bytes of headroom)                                |
+---------+-------------------------------------------------------+
|  $03F9  |  AptTempEndLo/Hi                                      |
|  $03F8  |  App Table overlapping check end address (2 bytes)    |
+---------+-------------------------------------------------------+
|  $03F7  |  AptTempSizeLo/Hi                                     |
|  $03F6  |  App Table overlapping check size register (2 bytes)  |
+---------+-------------------------------------------------------+
|  $03F5  |  AptTempLoadLo/Hi                                     |
|  $03F4  |  App Table overlapping check load address (2 bytes)   |
+---------+-------------------------------------------------------+
|  $03F3  |  AptSegLo/Hi                                          |
|  $03F2  |  VMM logical segment pointer to App Table (2 bytes)   |
+---------+-------------------------------------------------------+
|  $03F1  |  DestBuf                                              |
|  $03CA  |  General destination scratch path buffer (40 bytes)   |
+---------+-------------------------------------------------------+
|  $03C9  |  SourceBuf                                            |
|  $03A2  |  General source scratch path buffer (40 bytes)        |
+---------+-------------------------------------------------------+
|  $03A1  |  EnvBank (Environment block REU bank index)           |
+---------+-------------------------------------------------------+
|  $03A0  |  EnvSegmentLo/Hi                                      |
|  $039F  |  VMM logical segment pointer to Environment (2 bytes) |
+---------+-------------------------------------------------------+
|  $039E  |  CurrentDevice (C64 active drive device: 8, 9, 10, 11) |
+---------+-------------------------------------------------------+
|  $039D  |  HandleTable                                          |
|         |  8 slots * 2 bytes = 16 bytes.                        |
|  $038E  |  For each slot: Byte 0 = Status (0=Free, 1=Open)       |
|         |                 Byte 1 = KERNAL LFN (Logical File No.)|
+---------+-------------------------------------------------------+
|  $038D  |  SpecificLoad (0 = Relocate program, 1 = Absolute)    |
+---------+-------------------------------------------------------+
|  $038C  |  CommandLen (Active length of CommandBuffer input)    |
+---------+-------------------------------------------------------+
|  $038B  |  CommandBuffer                                        |
|  $033C  |  Active shell command line text buffer (80 bytes)     |
+---------+-------------------------------------------------------+
```

### File I/O Internal State (ShellExt Segment)

`src/command64/file.asm` keeps `fileRead`/`fileWrite`/`fileOpen`'s working
state as plain labelled bytes in the `ShellExt` segment (moved there because
the `File` segment's fixed `$0D00` window has no slack left — same reasoning
as `aptRelocate` in `loader.asm`). These are internal to the file subsystem,
not part of the OS Service Bus API contract, and their absolute addresses
shift between builds along with the rest of `ShellExt`/`AppTable`, so they
are documented here by label rather than fixed address:

| Label | Purpose |
| --- | --- |
| `CdrDevice` / `CdrRetried` | `checkDeviceReady`'s device number and power-on-banner retry flag. |
| `FileLenLo`/`Hi` | Caller-requested byte count for the current `fileRead`/`fileWrite` call (copied from `HexValLo/Hi` by `ahRead`/`ahWrite` in `api.asm` before the call). |
| `ReadCountLo`/`Hi`, `WriteCountLo`/`Hi` | Bytes actually transferred so far in the current `fileRead`/`fileWrite` loop; copied back into `HexValLo/Hi` on return. |
| `IoBufPtrLo`/`Hi` | Caller's destination/source buffer pointer, advanced one byte per loop iteration. |
| `SaveOffset` | Byte offset into the source range for `DOS_WRITE_FILE`-driven saves that stream in chunks. |
| `OpenMode` | Stashed copy of `HexValLo` (0 = Read, 1 = Write) for the duration of `fileOpen`. |
| `OpenType` | Stashed copy of `HexValHi` (file type character) for the duration of `fileOpen`; see `DOS_OPEN_FILE` in [OS Service Bus API Reference](api-reference.md) for the default-to-SEQ fallback behavior. |

---

## 4. REU Virtual Memory Space (Up to 16MB)

The Virtual Memory Manager (VMM) virtualizes up to 16MB of Ram Expansion Unit (REU) memory into 4KB pages. Page allocation is tracked using a 4096-byte **Memory Control Table (MCT)** located in base RAM at `$C000-$CFFF`.

### VMM Page Allocation Logic

* **MCT Position `$C000 + i`**: Represents the status of REU Page `i` (representing 4KB).
* **MCT Status Codes**:
  * `$00` (`PAGE_FREE`): Page is unallocated.
  * `$01` (`PAGE_HEAD`): Page is the starting point of an allocation.
  * `$02` (`PAGE_TAIL`): Page is a continuation block of a multi-page allocation.

### System Allocated Pages in REU

Upon boot, the OS initializes two structures in REU space:

1. **Master Environment Block (Page 0)**: Located at VMM segment pointer stored in `EnvSegment` ($039F-$03A0). Allocates a 4KB page. Stores shell environment variables configured by `SET` and `PATH` as double-null terminated strings (`VAR=VAL\0VAR=VAL\0\0`).
2. **Application Table Block (Page 1)**: Located at VMM segment pointer stored in `AptSegment` ($03F2-$03F3). Allocates a 4KB page. Manages a 16-slot registered application index (40 bytes per entry stride, 4-byte header at offset 0).

---

## 5. VMM Address Translation (C64 RAM -> REU Registers)

To read or write bytes located in virtual memory, user applications pass a 16-bit logical Segment (`VmmSegLo/Hi`), 16-bit logical Offset (`VmmOffLo/Hi`), and 1MB Bank index (`VmmBank`). The VMM routine translates this logical format into the C64 REU hardware DMA register layout.

### Translation Formula

A logical segment pointer represents a block of 16-byte paragraphs. The physical address is derived by:

$$\text{Physical Address (24-bit)} = (\text{VmmSeg} \times 16) + \text{VmmOff}$$

$$\text{REU Bank Offset} = \text{VmmBank} \times 16 + \text{Physical Address High Byte (Bits 16-23)}$$

### Register Mapping Diagram

```text
    LOGICAL SPECIFIERS                       REU DMA HARDWARE REGISTERS ($DF00-$DF0A)
    
   +--------------------+
   |   VmmSegLo / Hi    | --[ Shift Left 4 Bits (x16) ]---------+
   +--------------------+                                       |
                                                                v
   +--------------------+                               [ 24-bit Addr Base ]
   |   VmmOffLo / Hi    | ------------------------------------> +  (Addition)
   +--------------------+                                       |
                                                                v
                                                       [ 24-Bit Result ]
                                                        /       |       \
                                                       /        |        \
                                                  Low Byte   Mid Byte   High Byte
                                                    (0-7)     (8-15)     (16-23)
                                                     |          |          |
                                                     v          v          |
                                                +---------+ +---------+    |
                                                | REU_REU | | REU_REU |    |
                                                | _ADDR_L | | _ADDR_H |    |
                                                +---------+ +---------+    |
                                                  ($DF04)     ($DF05)      v
   +--------------------+                                                  |
   |      VmmBank       | --[ Shift Left 4 (x16) ]---------------------> + | (Addition)
   |       (0-15)       |                                                | |
   v--------------------+                                                v v
                                                                    +---------+
                                                                    | REU_REU |
                                                                    |  BANK   |
                                                                    +---------+
                                                                      ($DF06)
```

During execution, standard C64 RAM pointer target addresses are written to `$DF02-$DF03` (`REU_C64_ADDR_L/H`), the byte size (1 byte for single accesses, or larger blocks for dynamic program swaps) is written to `$DF07-$DF08` (`REU_LEN_L/H`), and the DMA execution trigger `REU_COMMAND` ($DF01) is set to execute a `STASH` ($90 - write) or `FETCH` ($91 - read) transfer.

---

## 6. Development Guidelines

### 6.1 OS Integration

Always use the stable entry point at **`$1000`** for OS services. Never jump directly into the OS kernel ($1200+) as these addresses may change between builds.

### 6.2 Compatibility

* **Binary Mode:** Always start your program with `CLD` to ensure binary arithmetic mode.
* **Character Set:** The OS starts in lowercase/mixed mode. Use PETSCII mixed-case encoding for strings.
* **Exit Strategy:** Always terminate your program via `DOS_EXIT ($4C)` to ensure the shell state is correctly reset.

### 6.3 Memory Management

Use the VMM API (`DOS_ALLOC_MEM`, `DOS_FREE_MEM`) to manage memory in the REU. Do not write directly to REU registers unless you are managing your own banked memory and are certain it does not conflict with the OS MCT.

### 6.4 Memory-Safe Loading

`LOAD` performs pre-flight validation before any bytes are transferred from disk:

* **Protected ranges**: any destination `< UserProgStart` or `>= $C000` is always rejected (`protected address`).
* **Address overlap**: for relocated loads (no explicit address given, or `SpecificLoad = 0`), the OS resolves the file's size ahead of time (`getFileSize`, via a directory-only read of the target file) and checks the full `[address, address + size)` range — including 16-bit wraparound — against every currently registered app's `[LoadAddr, LoadAddr + Size)` range (`aptCheckRange`). A collision is rejected (`address overlap`) before the KERNAL `LOAD` call begins, so memory is never partially clobbered.
* **Auto-slotting**: if `LOAD` is invoked with no address at all, `aptFindFreeRegion` scans page-aligned candidates upward from `UserProgStart`, skipping past any colliding registered app or protected region, and picks the first range large enough to hold the file. If no region fits below `$C000`, `LOAD` reports `out of memory`.
* On success, `LOAD` prints a `name / addr / size` report (same format as `APPS`/`PS`) for the newly registered program.

### 6.5 Binary Relocator

Programs do not have to be compiled exactly for the current `UserProgStart` to be loadable at an arbitrary address. A relocatable binary is produced by compiling the same source twice at a one-page (`$100`) offset and post-processing both outputs with `tools/reloc.py`, which diffs the two builds to find every absolute high-byte reference and appends a footer to the binary: `BaseAddrLo/Hi` (compile-time origin), `TableSizeLo/Hi` (number of patch offsets), a relocation table (16-bit code offsets, one per patch site), and a 2-byte magic marker (`'R'`, `'6'`).

At load time, `aptRelocate` checks for this magic footer. If present, it computes `PageOffset = (actual load page) - BaseAddrHi` and adds it to the high byte at every patch offset, then registers the program using only the code size (excluding the appended table/footer). If the magic is absent, the file is treated as an ordinary non-relocatable `.PRG` and registered as-is at its full loaded size.

## 7. Build System

The project is built using a cross-platform **CMake** build system (minimum version 3.20) and **Kick Assembler v5.25**.

* **Main Entry Point**: `src/command64.asm`
* **CMake Configuration**: Run `cmake -B build` followed by `cmake --build build` to compile the operating system, utilities, and test suites.
* **GNU Make Wrapper**: A `Makefile` proxy is provided at the repository root for convenience. You can run standard targets like `make all`, `make image`, or `make clean` which are forwarded directly to CMake.
* **Output**: Output binaries (`command64.prg`, `debug.prg`, etc.) are placed under the `build/` directory.

### 7.1 External Application Versioning Workflow

External user-space applications (located in `src/external/`) must follow a strict versioning workflow that increments a build counter at compile time whenever the application source files are modified.

1. **Subdirectory**: Place the application sources in a new folder `src/external/<appname>/` with a main entry assembler file (e.g., `<appname>.asm`).
2. **Persistent Build Counter File**: Create a file named `BUILD_<APPNAME_UPPER>` at the repository root containing the initial build number (usually `1000`).
3. **Assembly Integration**:
   * Define version major, minor, and stage in the main assembly file:

     ```assembly
     .const VERSION_MAJOR = "0"
     .const VERSION_MINOR = "1"
     .const VERSION_STAGE = "0"
     #import "build_<appname>.inc"
     ```

   * Embed the version and build number in the application startup/identification text using `BUILD_NUMBER`:

     ```assembly
     .text "MYAPP v" + VERSION_MAJOR + "." + VERSION_MINOR + "." + VERSION_STAGE + "." + BUILD_NUMBER
     ```

4. **CMake Target**: Update `CMakeLists.txt` to define the target using the `add_external_app` helper function:

   ```cmake
   file(GLOB_RECURSE MYAPP_SRCS "src/external/myapp/*.asm" "include/*.inc")
   set(MYAPP_ENTRY "src/external/myapp/myapp.asm")
   add_external_app(myapp "${MYAPP_ENTRY}" MYAPP_SRCS 1000)
   ```

   This helper automatically configures the target, schedules the build number increment script on modification of source files, and enforces that the `BUILD_MYAPP` file exists at configure time.
